﻿namespace SimpleDiExample.DependencyInjectionExample
{
    public interface IFortuneTeller
    {
        public void TellFortune();
    }
}
