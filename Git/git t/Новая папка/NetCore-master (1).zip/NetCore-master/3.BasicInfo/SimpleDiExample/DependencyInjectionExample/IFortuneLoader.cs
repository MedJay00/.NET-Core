﻿namespace SimpleDiExample.DependencyInjectionExample
{
    public interface IFortuneLoader
    {
        public string LoadFortune();
    }
}
